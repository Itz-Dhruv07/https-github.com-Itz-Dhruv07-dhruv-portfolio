import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Github, 
  Mail, 
  MessageSquare, 
  Search, 
  Code2, 
  Cpu, 
  Layers, 
  ExternalLink,
  Globe,
  Terminal,
  Gamepad2,
  Server,
  BrainCircuit,
  ChevronRight
} from 'lucide-react';

// Mock data for the portfolio
const SKILLS = {
  languages: ['c+', 'c#', 'c++', 'JavaScript', 'python', 'Java', 'XML', 'ASM', 'Ruby', 'Rust', 'BrainFuck'],
  software: ['VS Code', 'Git', 'Docker', 'Postman', 'Figma', 'Unity', 'Blender'],
  frameworks: ['React', 'Next.js', 'Node.js', 'Express', 'Tailwind CSS', 'TypeScript', 'Three.js'],
  competencies: ['Frontend Dev', 'Backend Dev', 'UI/UX Design', 'Game Dev', 'System Architecture']
};

const REPOS = [
  {
    name: 'Discord-Clone',
    description: 'A full-stack real-time messaging application inspired by Discord.',
    language: 'TypeScript',
    color: '#3178c6',
    stars: 12,
    date: 'Feb 20, 2026'
  },
  {
    name: 'AI-Portfolio-Generator',
    description: 'An automated tool to generate stunning portfolios using Gemini AI.',
    language: 'React',
    color: '#61dafb',
    stars: 45,
    date: 'Feb 15, 2026'
  },
  {
    name: 'Game-Engine-Core',
    description: 'A lightweight 2D game engine built from scratch in C++.',
    language: 'C++',
    color: '#f34b7d',
    stars: 8,
    date: 'Jan 28, 2026'
  },
  {
    name: 'Neural-Net-Visualizer',
    description: 'Interactive visualization of neural network layers and activations.',
    language: 'Python',
    color: '#3572A5',
    stars: 22,
    date: 'Jan 10, 2026'
  }
];

export default function App() {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredRepos = REPOS.filter(repo => 
    repo.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    repo.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-discord-darkest selection:bg-discord-blurple/30">
      {/* Floating Top Nav */}
      <nav className="fixed top-6 left-1/2 -translate-x-1/2 z-50">
        <div className="bg-discord-darker/80 backdrop-blur-md border border-white/10 rounded-full px-4 py-2 flex items-center gap-4 shadow-2xl">
          <div className="flex items-center gap-2 pr-4 border-r border-white/10">
            <div className="w-8 h-8 rounded-full overflow-hidden border border-white/10">
              <img 
                src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=40&h=40&auto=format&fit=crop" 
                alt="Dhruv" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="text-sm font-semibold">Dhruv</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="https://github.com/Itz-Dhruv07" target="_blank" rel="noreferrer" className="text-discord-gray hover:text-white transition-colors">
              <Github size={20} />
            </a>
            <div className="w-px h-4 bg-white/10" />
            <div className="flex items-center gap-2 text-xs font-medium text-discord-gray">
              <div className="w-2 h-2 rounded-full bg-discord-green animate-pulse" />
              Online
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-3xl mx-auto pt-32 pb-20 px-6 space-y-8">
        {/* Profile Hero Section */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="discord-card text-center relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-discord-blurple via-discord-fuchsia to-discord-red" />
          
          <div className="relative inline-block mb-6">
            <div className="w-32 h-32 rounded-full border-4 border-discord-darker overflow-hidden shadow-2xl mx-auto">
              <img 
                src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=200&h=200&auto=format&fit=crop" 
                alt="Dhruv" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute bottom-2 right-2 w-8 h-8 rounded-full bg-discord-darker p-1">
              <div className="w-full h-full rounded-full bg-discord-green border-2 border-discord-darker" />
            </div>
          </div>

          <h1 className="text-4xl font-bold mb-1">Dhruv</h1>
          <p className="text-discord-blurple font-medium mb-6">@dhruv_dev</p>

          <p className="text-discord-gray max-w-lg mx-auto leading-relaxed mb-8">
            I love to build logic for everything and integrate it seamlessly. 
            Full-stack Developer, UI/UX Enthusiast, and Game Programmer. 
            Always exploring the intersection of design and technology.
          </p>

          <div className="grid grid-cols-3 gap-4 max-w-sm mx-auto">
            <div className="bg-discord-dark p-3 rounded-xl border border-white/5">
              <div className="text-xl font-bold">1.2k</div>
              <div className="text-[10px] uppercase tracking-wider text-discord-gray font-bold">Followers</div>
            </div>
            <div className="bg-discord-dark p-3 rounded-xl border border-white/5">
              <div className="text-xl font-bold">450</div>
              <div className="text-[10px] uppercase tracking-wider text-discord-gray font-bold">Following</div>
            </div>
            <div className="bg-discord-dark p-3 rounded-xl border border-white/5">
              <div className="text-xl font-bold">42</div>
              <div className="text-[10px] uppercase tracking-wider text-discord-gray font-bold">Repos</div>
            </div>
          </div>
        </motion.section>

        {/* Skills Section */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-6"
        >
          <div className="flex items-center gap-3 text-discord-gray">
            <Cpu size={20} />
            <h2 className="text-xl font-bold text-white uppercase tracking-tight">Building Projects/Skills</h2>
          </div>

          <div className="space-y-4">
            {/* Languages */}
            <div className="discord-card">
              <div className="flex items-center gap-2 mb-4 text-discord-blurple">
                <Globe size={18} />
                <h3 className="text-sm font-bold uppercase tracking-wider">Languages</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {SKILLS.languages.map(skill => (
                  <span key={skill} className="discord-pill">{skill}</span>
                ))}
              </div>
            </div>

            {/* Software & Tools */}
            <div className="discord-card">
              <div className="flex items-center gap-2 mb-4 text-discord-fuchsia">
                <Terminal size={18} />
                <h3 className="text-sm font-bold uppercase tracking-wider">Software & Tools</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {SKILLS.software.map(skill => (
                  <span key={skill} className="discord-pill">{skill}</span>
                ))}
              </div>
            </div>

            {/* SDKs & Frameworks */}
            <div className="discord-card">
              <div className="flex items-center gap-2 mb-4 text-discord-green">
                <Layers size={18} />
                <h3 className="text-sm font-bold uppercase tracking-wider">SDKs & Frameworks</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {SKILLS.frameworks.map(skill => (
                  <span key={skill} className="discord-pill">{skill}</span>
                ))}
              </div>
            </div>

            {/* Core Competencies */}
            <div className="discord-card">
              <div className="flex items-center gap-2 mb-4 text-discord-yellow">
                <BrainCircuit size={18} />
                <h3 className="text-sm font-bold uppercase tracking-wider">Core Competencies</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {SKILLS.competencies.map(skill => (
                  <span key={skill} className="discord-pill">{skill}</span>
                ))}
              </div>
            </div>
          </div>
        </motion.section>

        {/* Repositories Section */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-6"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 text-discord-gray">
              <Code2 size={24} />
              <h2 className="text-2xl font-bold text-white">Repositories</h2>
            </div>
          </div>

          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-discord-gray" size={18} />
            <input 
              type="text" 
              placeholder="Search repositories..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-discord-darker border border-white/10 rounded-xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:border-discord-blurple transition-colors"
            />
          </div>

          <div className="grid gap-4">
            <AnimatePresence mode="popLayout">
              {filteredRepos.map((repo, index) => (
                <motion.div
                  key={repo.name}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="discord-card group hover:border-discord-blurple/50 transition-all cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-discord-dark rounded-lg text-discord-gray group-hover:text-discord-blurple transition-colors">
                        <Github size={18} />
                      </div>
                      <h3 className="font-bold text-lg">{repo.name}</h3>
                    </div>
                    <span className="text-[10px] font-bold uppercase bg-discord-dark px-2 py-1 rounded border border-white/5 text-discord-gray">
                      Public
                    </span>
                  </div>
                  
                  <p className="text-sm text-discord-gray mb-6 line-clamp-2">
                    {repo.description}
                  </p>

                  <div className="flex items-center justify-between pt-4 border-t border-white/5">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: repo.color }} />
                        <span className="text-xs text-discord-gray font-medium">{repo.language}</span>
                      </div>
                      <div className="text-xs text-discord-gray font-medium">{repo.date}</div>
                    </div>
                    <ChevronRight size={16} className="text-discord-gray group-hover:translate-x-1 transition-transform" />
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            
            {filteredRepos.length === 0 && (
              <div className="text-center py-12 text-discord-gray">
                No repositories found matching your search.
              </div>
            )}
          </div>
        </motion.section>

        {/* Contact Section */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="discord-card text-center space-y-6"
        >
          <div className="space-y-2">
            <h2 className="text-3xl font-bold">Let's Connect</h2>
            <p className="text-discord-gray max-w-md mx-auto">
              Whether you have a question about low-level programming, want to discuss game mechanics, or just want to say hi, my inbox is open.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a 
              href="mailto:workwithdhruvdev@gmail.com"
              className="discord-button-secondary w-full sm:w-auto justify-center"
            >
              <Mail size={18} />
              Email Me
            </a>
            <a 
              href="https://dsc.gg/madarmygaming"
              target="_blank"
              rel="noreferrer"
              className="discord-button-primary w-full sm:w-auto justify-center"
            >
              <MessageSquare size={18} />
              Discord
            </a>
          </div>
          
          <a 
            href="https://github.com/Itz-Dhruv07"
            target="_blank"
            rel="noreferrer"
            className="discord-button-secondary w-full sm:w-auto mx-auto justify-center"
          >
            <Github size={18} />
            GitHub
          </a>
        </motion.section>
      </main>

      <footer className="text-center py-10 text-discord-gray text-xs border-t border-white/5">
        <p>© 2026 Dhruv • Built with ♥️ by Dhruv</p>
      </footer>
    </div>
  );
}
